<?php
require_once '../config.db.php';
session_start();

if (isset($_POST['edit_save_sbm']) && isset($_POST['rem_id'])) {
    global $mysqli;
    $sql = "UPDATE reminders SET reminder=?, notes=?, date=? WHERE id=?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("sssi", $_POST['edit_reminder'], $_POST['edit_notes'], $_POST['edit_date'], $_POST['rem_id']);
    $stmt->execute();
    header('Location: /index.php');
}