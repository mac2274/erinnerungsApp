<?php
require_once './config.db.php';

global $mysqli;
    require './modul/frm_reminder.php';

    $sql = "SELECT * FROM reminders WHERE userId=?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $_SESSION['id']);
    $stmt->execute();
    $user = $stmt->get_result();
    while ($row = $user->fetch_assoc()) {
        echo '<br><form action="/reminder/delete.php" method="post">
                <input type="hidden" name="rem_id" value="' . $row['id'] . '">
                <input type="submit" name="sbm_delete" value="Löschen"> 
                <input type="button" name="sbm_edit" value="Bearbeiten" onclick="show(' . $row['id'] . ')"> '
            . $row['reminder'] . ' ' . $row['notes'] . ' ' . $row['date'] . '
              </form>';
        echo '<form action="/reminder/edit.php" method="POST" id="edit_' . $row['id'] . '"class="hidden">
        <input type="hidden" name="rem_id" value="' . $row['id'] . '">
                <label for="edit_reminder">Errinnerung:</label>
                <input type="text" name="edit_reminder" value="' . $row['reminder'] . '" required>
                <label for="edit_notes">Notizen:</label>
                <input type="text" name="edit_notes" value="' . $row['notes'] . '">
                <label for="edit_date">Fällig:</label>
                <input type="date" name="edit_date" value="' . $row['date'] . '">
                <input type="submit" value="Speichern" name="edit_save_sbm">
             </form>';
    }
