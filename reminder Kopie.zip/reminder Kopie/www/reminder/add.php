<?php
require_once '../config.db.php';
session_start();

if (isset($_SESSION['eingeloggt'])) {
    global $mysqli;
    global $mysqli;
    $sql = "INSERT INTO reminders (reminder, notes, date, userId) VALUES (?,?,?,?)";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("sssi", $_POST['frm_reminder'], $_POST['frm_notes'], $_POST['frm_date'], $_SESSION['id']);
    $stmt->execute();
    if ($stmt->errno) {
        echo "Fehler beim erstellen der Errinnerung " .  $stmt->error;
    }
    header('Location: /index.php');
}
