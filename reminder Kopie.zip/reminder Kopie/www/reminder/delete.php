<?php
require_once '../config.db.php';
session_start();

if (isset($_SESSION['eingeloggt']) && isset($_POST['sbm_delete']) && isset($_POST['rem_id'])) {
    global $mysqli;
    $sql = "DELETE FROM reminders WHERE id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $_POST['rem_id']);
    $stmt->execute();

    header('Location: /index.php');
}