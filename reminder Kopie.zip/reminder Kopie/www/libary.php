<?php
require_once 'config.db.php';

function insertFormLogin() {
    if (isset($_POST['frm_login_sbm'])) {
        require './modul/frm_login.php';
    } 
}


function insertFormRegistration() {
if (isset($_POST['frm_registration_sbm'])) {
    require './modul/registration.php';
}
}

?>