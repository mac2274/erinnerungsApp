<?php

echo '<form action="/user/registration.php" method="POST">
    Vorname: <input type="text" name="frm_name" required> <br>
    Nachname: <input type="text" name="frm_surname" required> <br>
    E-Mail: <input type="email" name="frm_email" required> <br>
    Password: <input type="password" name="frm_password" required> <br>
    <input type="submit" value="registrieren" name="frm_registration">
</form>';