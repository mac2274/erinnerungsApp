<?php

echo '<form action="/reminder/add.php" method="POST">
    <label for="frm_reminder">Name der Errinnerung:</label>
    <input type="text" name="frm_reminder" required>
    <label for="frm_notes">Weitere Notizen:</label>
    <input type="text" name="frm_notes">
    <label for="frm_date">Fällig am:</label>
    <input type="date" name="frm_date" value="2024-12-31">
    <input type="submit" value="Erstellen" name="frm_add_sbm">
</form>';