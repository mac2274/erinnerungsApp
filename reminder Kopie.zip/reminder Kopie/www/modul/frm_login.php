<?php


echo '<form action="/user/login.php" method="POST">
    E-Mail: <input type="email" name="frm_email" required> <br>
    Password: <input type="password" name="frm_password" required> <br>
    <input type="submit" value="Login" name="frm_login">
</form>';