<?php

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$mysqli = new mysqli('db', 'reminder_app','PNrx(Di*@_[.SY90',database: 'reminder_app');
if ($mysqli->connect_errno) {
    throw new RuntimeException('mysqli-Verbindungsfehler: '. $mysqli->connect_error);
}
