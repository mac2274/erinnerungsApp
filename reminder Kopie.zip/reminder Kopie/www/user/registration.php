<?php
require_once '../config.db.php';
session_start();

if (isset($_POST['frm_registration'])) {
global $mysqli;
$pwd = password_hash($_POST['frm_password'], PASSWORD_BCRYPT);
$sql = "INSERT INTO users (name, surname, email, password) VALUES (?,?,?,?)";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("ssss", $_POST['frm_name'], $_POST['frm_surname'], $_POST['frm_email'], $pwd);
$stmt->execute();
if ($stmt->errno) {
    echo "Fehler beim der Registration";
} else {
    header('Location: /index.php');
}
}