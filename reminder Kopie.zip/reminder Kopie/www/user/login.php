<?php
require_once '../config.db.php';
session_start();

if (isset($_POST['frm_login'])) {
    global $mysqli;

    $sql = "SELECT * FROM users WHERE email=?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("s", $_POST['frm_email']);
    $stmt->execute();
    $user = $stmt->get_result();
    $loginSuc = false;

    while ($row = $user->fetch_assoc()) {
        if ($user && password_verify($_POST['frm_password'], $row['password'])) {
            $_SESSION['eingeloggt'] = true;
            $_SESSION['id'] = $row['id'];
            $loginSuc = true;
            header('Location: /index.php');
        }
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$loginSuc) {
        echo "Deine Login-Daten sind falsch.";
    }
    if ($stmt->errno) {
        echo "Fehler beim Login";
    }
}
