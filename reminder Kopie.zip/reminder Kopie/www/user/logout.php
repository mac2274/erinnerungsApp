<?php
require_once '../config.db.php';
session_start();

    session_destroy();
    $loginSuc = false;
    header('Location: /index.php');

 